
# 🚀 GitHub Actions - Automatische App Builds

## Setup Anleitung (10 Minuten)

### Schritt 1: GitHub Repository erstellen
1. Gehen Sie zu https://github.com/new
2. Repository Name: `ai-voice-changer-app`
3. Wählen Sie "Public" oder "Private" 
4. Klicken Sie "Create repository"

### Schritt 2: Code hochladen
```bash
git remote add origin https://github.com/IHR-USERNAME/ai-voice-changer-app.git
git branch -M main
git push -u origin main
```

### Schritt 3: Secrets konfigurieren
Gehen Sie zu: https://github.com/IHR-USERNAME/ai-voice-changer-app/settings/secrets/actions

**Apple Secrets hinzufügen:**
- `APPLE_ID`: Ihre Apple ID E-Mail
- `APPLE_ID_PASSWORD`: App-spezifisches Passwort (nicht Ihr normales Passwort!)
- `APPLE_TEAM_ID`: Finden Sie hier: https://developer.apple.com/account/#!/membership/

**Android Secrets hinzufügen:**
- `ANDROID_KEYSTORE_PASSWORD`: Ihr Android Keystore Passwort
- `ANDROID_KEY_ALIAS`: Ihr Key Alias
- `ANDROID_KEY_PASSWORD`: Ihr Key Passwort

### Schritt 4: Apple App-spezifisches Passwort erstellen
1. Gehen Sie zu: https://appleid.apple.com/sign-in
2. Anmelden mit Ihrer Apple ID
3. Sektion "App-Specific Passwords" 
4. Klicken Sie "Generate Password..."
5. Label: "GitHub Actions"
6. Kopieren Sie das generierte Passwort

### Schritt 5: Android Keystore erstellen
```bash
keytool -genkey -v -keystore ai-voice-changer.keystore -alias aivoicechanger -keyalg RSA -keysize 2048 -validity 10000
```

### Schritt 6: Build starten
1. Push Code zu GitHub
2. Automatischer Build startet
3. Apps werden in "Actions" Tab downloadbar

## ✅ Fertige Apps downloaden
Nach 15-20 Minuten finden Sie hier:
- **iOS App (.ipa)**: https://github.com/IHR-USERNAME/ai-voice-changer-app/actions
- **Android App (.aab)**: https://github.com/IHR-USERNAME/ai-voice-changer-app/actions

## 🔄 Automatische Updates
Jede Änderung am Code löst automatisch einen neuen Build aus!
