import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.leitnerprojects.aivoicechanger',
  appName: 'AI Voice Changer',
  webDir: 'out',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    Camera: {
      permissions: ['microphone']
    },
    Device: {
      permissions: ['microphone']
    }
  },
  ios: {
    contentInset: 'automatic',
    backgroundColor: '#000000'
  },
  android: {
    backgroundColor: '#000000',
    allowMixedContent: true
  }
};

export default config;
