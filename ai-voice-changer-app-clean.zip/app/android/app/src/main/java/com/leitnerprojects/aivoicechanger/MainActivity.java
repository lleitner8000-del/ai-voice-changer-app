package com.leitnerprojects.aivoicechanger;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
