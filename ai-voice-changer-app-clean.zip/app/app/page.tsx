
import HeroSection from '@/components/hero-section';
import AppsSection from '@/components/apps-section';
import AIVoiceChanger from '@/components/ai-voice-changer';
import AboutSection from '@/components/about-section';
import ContactSection from '@/components/contact-section';

export default function Home() {
  return (
    <>
      <HeroSection />
      <AppsSection />
      <AIVoiceChanger />
      <AboutSection />
      <ContactSection />
    </>
  );
}
