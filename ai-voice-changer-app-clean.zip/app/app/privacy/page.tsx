
'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowLeft, Shield } from 'lucide-react';
import { useLanguage } from '@/contexts/language-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function PrivacyPage() {
  const { language } = useLanguage();

  const content = {
    de: {
      title: 'Datenschutzerklärung',
      lastUpdated: 'Letzte Aktualisierung: 14. August 2025',
      intro: 'Diese Datenschutzerklärung beschreibt unsere Richtlinien und Verfahren zur Erfassung, Verwendung und Offenlegung Ihrer Informationen, wenn Sie den Service nutzen, und informiert Sie über Ihre Datenschutzrechte und wie das Gesetz Sie schützt.',
      backToHome: 'Zurück zur Startseite',
      sections: {
        interpretation: {
          title: '1. Begriffsbestimmungen',
          content: `Für die Zwecke dieser Datenschutzerklärung:
          
**Unternehmen** (in dieser Vereinbarung entweder als "das Unternehmen", "wir", "uns" oder "unser" bezeichnet) bezieht sich auf Leitner Projects, Schweiz.

**Sie** bezieht sich auf die Person, die auf den Service zugreift oder ihn nutzt.`
        },
        dataCollection: {
          title: '2. Erfassung und Verwendung Ihrer persönlichen Daten',
          content: `**Arten der erfassten Daten:**

**Persönliche Daten**
Bei der Nutzung unseres Service können wir Sie bitten, bestimmte persönlich identifizierbare Informationen anzugeben, die verwendet werden können, um Sie zu kontaktieren oder zu identifizieren. Persönlich identifizierbare Informationen können umfassen:
- E-Mail-Adresse
- Vor- und Nachname
- Nutzungsdaten

**Nutzungsdaten**
Nutzungsdaten werden automatisch bei der Nutzung des Service erfasst und können Informationen wie die Internet-Protocol-Adresse (IP-Adresse) Ihres Geräts, Browsertyp, Browserversion, die Seiten unseres Service, die Sie besuchen, die Zeit und das Datum Ihres Besuchs, die auf diesen Seiten verbrachte Zeit, eindeutige Gerätekennungen und andere Diagnosedaten umfassen.`
        },
        cookies: {
          title: '3. Verwendung von Cookies und Tracking-Technologien',
          content: `Wir verwenden Cookies und ähnliche Tracking-Technologien, um die Aktivitäten auf unserem Service zu verfolgen und bestimmte Informationen zu speichern. Tracking-Technologien sind Beacons, Tags und Skripte zur Sammlung und Verfolgung von Informationen sowie zur Verbesserung und Analyse unseres Service.

Sie können Ihren Browser so einstellen, dass er alle Cookies ablehnt oder anzeigt, wenn ein Cookie gesendet wird. Wenn Sie jedoch keine Cookies akzeptieren, können Sie möglicherweise nicht alle Teile unseres Service nutzen.`
        },
        dataUse: {
          title: '4. Verwendung Ihrer persönlichen Daten',
          content: `Das Unternehmen kann persönliche Daten für folgende Zwecke verwenden:
- Zur Bereitstellung und Aufrechterhaltung unseres Service
- Zur Verwaltung Ihres Kontos
- Für die Vertragserfüllung
- Zur Kontaktaufnahme mit Ihnen
- Zur Bereitstellung von Nachrichten, Sonderangeboten und allgemeinen Informationen
- Zur Verwaltung Ihrer Anfragen
- Für Geschäftsübertragungen
- Für andere Zwecke`
        },
        dataRetention: {
          title: '5. Aufbewahrung Ihrer persönlichen Daten',
          content: `Das Unternehmen wird Ihre persönlichen Daten nur so lange aufbewahren, wie es für die in dieser Datenschutzerklärung dargelegten Zwecke erforderlich ist. Wir werden Ihre persönlichen Daten in dem Umfang aufbewahren und verwenden, der zur Erfüllung unserer rechtlichen Verpflichtungen erforderlich ist.`
        },
        dataSecurity: {
          title: '6. Sicherheit Ihrer persönlichen Daten',
          content: `Die Sicherheit Ihrer persönlichen Daten ist uns wichtig, aber denken Sie daran, dass keine Übertragungsmethode über das Internet oder elektronische Speichermethode 100% sicher ist. Während wir uns bemühen, kommerziell akzeptable Mittel zum Schutz Ihrer persönlichen Daten zu verwenden, können wir deren absolute Sicherheit nicht garantieren.`
        },
        rights: {
          title: '7. Ihre Datenschutzrechte',
          content: `Je nach Ihrem Standort haben Sie verschiedene Rechte in Bezug auf Ihre persönlichen Daten:
- Das Recht auf Zugang zu Ihren Daten
- Das Recht auf Berichtigung unrichtiger Daten  
- Das Recht auf Löschung Ihrer Daten
- Das Recht auf Einschränkung der Verarbeitung
- Das Recht auf Datenübertragbarkeit
- Das Recht auf Widerspruch gegen die Verarbeitung`
        },
        contact: {
          title: '8. Kontaktieren Sie uns',
          content: `Wenn Sie Fragen zu dieser Datenschutzerklärung haben, können Sie uns kontaktieren:
- Per E-Mail: bluepeakhelps@gmail.com
- Auf dieser Seite: https://bluepeak-apps.com`
        }
      }
    },
    en: {
      title: 'Privacy Policy',
      lastUpdated: 'Last updated: August 14, 2025',
      intro: 'This Privacy Policy describes Our policies and procedures on the collection, use and disclosure of Your information when You use the Service and tells You about Your privacy rights and how the law protects You.',
      backToHome: 'Back to Home',
      sections: {
        interpretation: {
          title: '1. Interpretation and Definitions',
          content: `For the purposes of this Privacy Policy:
          
**Company** (referred to as either "the Company", "we", "us" or "our") refers to Leitner Projects, Switzerland.

**You** refers to the individual accessing or using the Service.`
        },
        dataCollection: {
          title: '2. Collecting and Using Your Personal Data',
          content: `**Types of Data Collected:**

**Personal Data**
While using Our Service, We may ask You to provide Us with certain personally identifiable information that can be used to contact or identify You. Personally identifiable information may include:
- Email address
- First name and last name
- Usage Data

**Usage Data**
Usage Data is collected automatically when using the Service and may include information such as Your Device's Internet Protocol address (IP address), browser type, browser version, the pages of our Service that You visit, the time and date of Your visit, the time spent on those pages, unique device identifiers and other diagnostic data.`
        },
        cookies: {
          title: '3. Use of Cookies and Tracking Technologies',
          content: `We use Cookies and similar tracking technologies to track the activity on Our Service and store certain information. Tracking technologies used are beacons, tags, and scripts to collect and track information and to improve and analyze Our Service.

You can instruct Your browser to refuse all Cookies or to indicate when a Cookie is being sent. However, if You do not accept Cookies, You may not be able to use some parts of our Service.`
        },
        dataUse: {
          title: '4. Use of Your Personal Data',
          content: `The Company may use Personal Data for the following purposes:
- To provide and maintain our Service
- To manage Your Account
- For the performance of a contract
- To contact You
- To provide You with news, special offers and general information
- To manage Your requests
- For business transfers
- For other purposes`
        },
        dataRetention: {
          title: '5. Retention of Your Personal Data',
          content: `The Company will retain Your Personal Data only for as long as is necessary for the purposes set out in this Privacy Policy. We will retain and use Your Personal Data to the extent necessary to comply with our legal obligations.`
        },
        dataSecurity: {
          title: '6. Security of Your Personal Data',
          content: `The security of Your Personal Data is important to Us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While We strive to use commercially acceptable means to protect Your Personal Data, We cannot guarantee its absolute security.`
        },
        rights: {
          title: '7. Your Privacy Rights',
          content: `Depending on Your location, You have various rights regarding Your personal data:
- The right to access Your data
- The right to rectify incorrect data
- The right to erasure of Your data
- The right to restrict processing
- The right to data portability
- The right to object to processing`
        },
        contact: {
          title: '8. Contact Us',
          content: `If you have any questions about this Privacy Policy, You can contact us:
- By email: bluepeakhelps@gmail.com
- On this page: https://bluepeak-apps.com`
        }
      }
    }
  };

  const currentContent = content[language as keyof typeof content];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      {/* Header */}
      <div className="bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                {currentContent.backToHome}
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-blue-600" />
              <span className="text-sm text-slate-600 dark:text-slate-400">
                {currentContent.lastUpdated}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold font-space-grotesk text-slate-900 dark:text-white mb-4">
              {currentContent.title}
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
              {currentContent.intro}
            </p>
          </div>

          <div className="space-y-8">
            {Object.entries(currentContent.sections).map(([key, section]) => (
              <Card key={key} className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-semibold text-slate-900 dark:text-white mb-4">
                    {section.title}
                  </h2>
                  <div className="prose prose-slate dark:prose-invert max-w-none">
                    <div className="whitespace-pre-line text-slate-600 dark:text-slate-300">
                      {section.content}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Note about placeholder data */}
          <Card className="mt-12 bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800">
            <CardContent className="p-6 text-center">
              <div className="text-yellow-800 dark:text-yellow-200">
                <strong>
                  {language === 'de' ? 'Hinweis:' : 'Note:'} 
                </strong>
                {language === 'de' 
                  ? ' Diese Datenschutzerklärung enthält Platzhalter. Bitte ersetzen Sie alle [EINFÜGEN] Markierungen mit Ihren tatsächlichen Unternehmensinformationen.'
                  : ' This privacy policy contains placeholders. Please replace all [INSERT] markings with your actual company information.'
                }
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
