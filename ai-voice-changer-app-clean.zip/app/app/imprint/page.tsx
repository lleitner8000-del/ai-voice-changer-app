
'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowLeft, Building2 } from 'lucide-react';
import { useLanguage } from '@/contexts/language-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function ImprintPage() {
  const { language } = useLanguage();

  const content = {
    de: {
      title: 'Impressum',
      subtitle: 'Angaben gemäß § 5 TMG',
      backToHome: 'Zurück zur Startseite',
      sections: {
        company: {
          title: 'Unternehmen',
          content: `Leitner Projects
Einzelunternehmen
Schweiz

Kontakt für geschäftliche Anfragen:
E-Mail: lleitner.projects@gmail.com`
        },
        contact: {
          title: 'Kontakt',
          content: `E-Mail: lleitner.projects@gmail.com
Website: https://bluepeak-apps.com`
        },
        management: {
          title: 'Vertreten durch',
          content: `Ludwig Leitner (Inhaber)`
        },
        registration: {
          title: 'Unternehmensform',
          content: `Einzelunternehmen
Noch nicht im Handelsregister eingetragen
Tätigkeit als Privatperson gemäß Schweizer Recht`
        },
        tax: {
          title: 'Mehrwertsteuer',
          content: `Noch nicht mehrwertsteuerpflichtig
Bei Erreichen der Umsatzgrenze erfolgt ordnungsgemäße Anmeldung`
        },
        liability: {
          title: 'Haftungsausschluss',
          content: `**Haftung für Inhalte**
Als Anbieter sind wir nach Schweizer Recht für eigene Inhalte auf diesen Seiten verantwortlich. Wir sind jedoch nicht verpflichtet, übermittelte oder gespeicherte fremde Informationen zu überwachen oder nach Umständen zu forschen, die auf eine rechtswidrige Tätigkeit hinweisen.

**Haftung für Links**
Unser Angebot enthält Links zu externen Websites Dritter, auf deren Inhalte wir keinen Einfluss haben. Deshalb können wir für diese fremden Inhalte auch keine Gewähr übernehmen. Für die Inhalte der verlinkten Seiten ist stets der jeweilige Anbieter oder Betreiber der Seiten verantwortlich.

**Urheberrecht**
Die durch die Seitenbetreiber erstellten Inhalte und Werke auf diesen Seiten unterliegen dem Schweizer Urheberrecht. Die Vervielfältigung, Bearbeitung, Verbreitung und jede Art der Verwertung außerhalb der Grenzen des Urheberrechtes bedürfen der schriftlichen Zustimmung des jeweiligen Autors bzw. Erstellers.`
        },
        dispute: {
          title: 'Streitschlichtung',
          content: `Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit: https://ec.europa.eu/consumers/odr/.
Unsere E-Mail-Adresse finden Sie oben im Impressum.

Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.`
        }
      }
    },
    en: {
      title: 'Imprint',
      subtitle: 'Legal Notice',
      backToHome: 'Back to Home',
      sections: {
        company: {
          title: 'Company',
          content: `Leitner Projects
Sole Proprietorship
Switzerland

Contact for business inquiries:
Email: lleitner.projects@gmail.com`
        },
        contact: {
          title: 'Contact',
          content: `Email: lleitner.projects@gmail.com
Website: https://bluepeak-apps.com`
        },
        management: {
          title: 'Represented by',
          content: `Ludwig Leitner (Owner)`
        },
        registration: {
          title: 'Business Form',
          content: `Sole Proprietorship
Not yet registered in the Commercial Register
Operating as private person under Swiss law`
        },
        tax: {
          title: 'VAT',
          content: `Not yet subject to VAT
Upon reaching turnover threshold, proper registration will be completed`
        },
        liability: {
          title: 'Disclaimer',
          content: `**Liability for Contents**
As service providers, we are liable for our own contents of these websites according to Swiss law. However, we are not under obligation to permanently monitor submitted or stored information or to search for evidences that indicate illegal activities.

**Liability for Links**
Our offer includes links to external third party websites. We have no influence on the contents of those websites, therefore we cannot guarantee for those contents. Providers or administrators of linked websites are always responsible for their own contents.

**Copyright**
Contents and compilations published on these websites by the providers are subject to Swiss copyright laws. Reproduction, editing, distribution as well as the use of any kind outside the scope of the copyright law require a written permission of the author or originator.`
        },
        dispute: {
          title: 'Dispute Resolution',
          content: `The European Commission provides a platform for online dispute resolution (ODR): https://ec.europa.eu/consumers/odr/.
Our email address can be found above in the imprint.

We are not willing or obliged to participate in dispute resolution proceedings at a consumer arbitration board.`
        }
      }
    }
  };

  const currentContent = content[language as keyof typeof content];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      {/* Header */}
      <div className="bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                {currentContent.backToHome}
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-blue-600" />
              <span className="text-sm text-slate-600 dark:text-slate-400">
                {currentContent.subtitle}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold font-space-grotesk text-slate-900 dark:text-white mb-4">
              {currentContent.title}
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-300">
              {currentContent.subtitle}
            </p>
          </div>

          <div className="space-y-8">
            {Object.entries(currentContent.sections).map(([key, section]) => (
              <Card key={key} className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-semibold text-slate-900 dark:text-white mb-4">
                    {section.title}
                  </h2>
                  <div className="prose prose-slate dark:prose-invert max-w-none">
                    <div className="whitespace-pre-line text-slate-600 dark:text-slate-300">
                      {section.content}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Legal compliance note */}
          <Card className="mt-12 bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
            <CardContent className="p-6 text-center">
              <div className="text-green-800 dark:text-green-200">
                <strong>
                  {language === 'de' ? 'Rechtlicher Hinweis:' : 'Legal Note:'} 
                </strong>
                {language === 'de' 
                  ? ' Alle Angaben entsprechen dem Schweizer Recht für Einzelunternehmen.'
                  : ' All information complies with Swiss law for sole proprietorships.'
                }
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
