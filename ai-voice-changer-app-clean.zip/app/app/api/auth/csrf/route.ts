
export async function GET() {
  return new Response(JSON.stringify({ 
    csrfToken: 'mock-csrf-token'
  }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
}
