
export async function POST() {
  return new Response(JSON.stringify({ 
    success: true,
    message: 'Mock signup successful',
    user: { id: 1, email: 'test@example.com' }
  }), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
}
