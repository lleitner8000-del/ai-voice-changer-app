
'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowLeft, FileText } from 'lucide-react';
import { useLanguage } from '@/contexts/language-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function TermsPage() {
  const { language } = useLanguage();

  const content = {
    de: {
      title: 'Allgemeine Geschäftsbedingungen',
      subtitle: 'Nutzungsbedingungen für BluePeak Apps',
      lastUpdated: 'Letzte Aktualisierung: 14. August 2025',
      backToHome: 'Zurück zur Startseite',
      intro: 'Diese Allgemeinen Geschäftsbedingungen ("AGB") regeln Ihre Nutzung unserer Apps und Services. Durch die Nutzung unserer Services stimmen Sie diesen Bedingungen zu.',
      sections: {
        definitions: {
          title: '1. Begriffsbestimmungen',
          content: `**Unternehmen** (auch "wir", "uns" oder "unser") bezeichnet [FIRMENNAME EINFÜGEN].
**Service** bezeichnet die von uns bereitgestellten Apps und Dienste.
**Sie** bezeichnet die Person, die unsere Services nutzt.
**App** bezeichnet unsere mobile Anwendung(en).`
        },
        acceptance: {
          title: '2. Annahme der Bedingungen',
          content: `Durch den Zugriff auf oder die Nutzung unserer Services bestätigen Sie, dass Sie diese AGB gelesen haben und sich damit einverstanden erklären, an sie gebunden zu sein. Falls Sie mit einem Teil dieser AGB nicht einverstanden sind, dürfen Sie unsere Services nicht nutzen.`
        },
        services: {
          title: '3. Beschreibung der Services',
          content: `Wir bieten KI-gestützte mobile Anwendungen, einschließlich aber nicht beschränkt auf Stimmenveränderer und andere innovative Tools. Unsere Services können kostenlose und kostenpflichtige Funktionen umfassen.`
        },
        userAccount: {
          title: '4. Benutzerkonto',
          content: `Für einige Services müssen Sie möglicherweise ein Konto erstellen. Sie sind verantwortlich für:
- Die Vertraulichkeit Ihrer Kontoinformationen
- Alle Aktivitäten, die unter Ihrem Konto stattfinden
- Die Benachrichtigung über unbefugte Nutzung

Sie müssen mindestens 13 Jahre alt sein, um unsere Services zu nutzen.`
        },
        payments: {
          title: '5. Zahlungen und Abonnements',
          content: `**Kostenpflichtige Services:** Einige unserer Services erfordern Zahlungen.
**Abonnements:** Abonnements verlängern sich automatisch, sofern nicht gekündigt.
**Rückerstattungen:** Rückerstattungen werden gemäß der Richtlinien des App Stores gewährt.
**Preisänderungen:** Wir behalten uns das Recht vor, Preise zu ändern.`
        },
        usage: {
          title: '6. Nutzungsregeln',
          content: `Sie dürfen unsere Services nicht nutzen für:
- Illegale oder schädliche Aktivitäten
- Verletzung von Rechten Dritter
- Verbreitung von Malware oder schädlichen Inhalten
- Umgehung unserer Sicherheitsmaßnahmen
- Belästigung oder Missbrauch anderer Nutzer`
        },
        content: {
          title: '7. Inhalte und geistiges Eigentum',
          content: `**Unsere Inhalte:** Alle Inhalte und Materialien unserer Services sind unser Eigentum.
**Ihre Inhalte:** Sie behalten das Eigentum an Inhalten, die Sie erstellen, gewähren uns aber Lizenzen zur Bereitstellung der Services.
**Urheberrecht:** Wir respektieren geistige Eigentumsrechte und erwarten dasselbe von unseren Nutzern.`
        },
        privacy: {
          title: '8. Datenschutz',
          content: `Ihre Privatsphäre ist uns wichtig. Unsere Datenschutzrichtlinie beschreibt, wie wir Ihre Informationen sammeln, verwenden und schützen. Durch die Nutzung unserer Services stimmen Sie auch unserer Datenschutzrichtlinie zu.`
        },
        termination: {
          title: '9. Beendigung',
          content: `**Durch Sie:** Sie können die Nutzung jederzeit beenden.
**Durch uns:** Wir können Ihren Zugang bei Verstoß gegen diese AGB beenden.
**Wirkung:** Nach Beendigung bleiben bestimmte Bestimmungen wirksam.`
        },
        liability: {
          title: '10. Haftungsbeschränkung',
          content: `Unsere Services werden "wie sie sind" bereitgestellt. Wir schließen alle Gewährleistungen aus, soweit gesetzlich zulässig. Unsere Haftung ist auf den größtmöglichen gesetzlich zulässigen Umfang beschränkt.`
        },
        changes: {
          title: '11. Änderungen der AGB',
          content: `Wir können diese AGB jederzeit ändern. Wesentliche Änderungen werden Ihnen mitgeteilt. Ihre fortgesetzte Nutzung nach Änderungen gilt als Zustimmung.`
        },
        contact: {
          title: '12. Kontakt',
          content: `Bei Fragen zu diesen AGB kontaktieren Sie uns:
E-Mail: legal@bluepeak-apps.com
Adresse: [ADRESSE EINFÜGEN]`
        }
      }
    },
    en: {
      title: 'Terms and Conditions',
      subtitle: 'Terms of Service for BluePeak Apps',
      lastUpdated: 'Last updated: August 14, 2025',
      backToHome: 'Back to Home',
      intro: 'These Terms and Conditions ("Terms") govern your use of our apps and services. By using our services, you agree to these terms.',
      sections: {
        definitions: {
          title: '1. Definitions',
          content: `**Company** (also "we", "us" or "our") refers to [INSERT COMPANY NAME].
**Service** refers to the apps and services provided by us.
**You** refers to the individual using our services.
**App** refers to our mobile application(s).`
        },
        acceptance: {
          title: '2. Acceptance of Terms',
          content: `By accessing or using our services, you confirm that you have read these Terms and agree to be bound by them. If you do not agree with any part of these Terms, you may not use our services.`
        },
        services: {
          title: '3. Description of Services',
          content: `We provide AI-powered mobile applications, including but not limited to voice changers and other innovative tools. Our services may include free and paid features.`
        },
        userAccount: {
          title: '4. User Account',
          content: `For some services, you may need to create an account. You are responsible for:
- The confidentiality of your account information
- All activities that occur under your account
- Notifying us of unauthorized use

You must be at least 13 years old to use our services.`
        },
        payments: {
          title: '5. Payments and Subscriptions',
          content: `**Paid Services:** Some of our services require payment.
**Subscriptions:** Subscriptions auto-renew unless canceled.
**Refunds:** Refunds are provided according to App Store policies.
**Price Changes:** We reserve the right to change prices.`
        },
        usage: {
          title: '6. Usage Rules',
          content: `You may not use our services for:
- Illegal or harmful activities
- Violating third-party rights
- Distributing malware or harmful content
- Circumventing our security measures
- Harassing or abusing other users`
        },
        content: {
          title: '7. Content and Intellectual Property',
          content: `**Our Content:** All content and materials in our services are our property.
**Your Content:** You retain ownership of content you create but grant us licenses to provide services.
**Copyright:** We respect intellectual property rights and expect the same from our users.`
        },
        privacy: {
          title: '8. Privacy',
          content: `Your privacy is important to us. Our Privacy Policy describes how we collect, use, and protect your information. By using our services, you also agree to our Privacy Policy.`
        },
        termination: {
          title: '9. Termination',
          content: `**By You:** You may terminate use at any time.
**By Us:** We may terminate your access for violating these Terms.
**Effect:** After termination, certain provisions remain in effect.`
        },
        liability: {
          title: '10. Limitation of Liability',
          content: `Our services are provided "as is." We disclaim all warranties to the extent permitted by law. Our liability is limited to the maximum extent legally permitted.`
        },
        changes: {
          title: '11. Changes to Terms',
          content: `We may modify these Terms at any time. Material changes will be communicated to you. Your continued use after changes constitutes acceptance.`
        },
        contact: {
          title: '12. Contact',
          content: `If you have questions about these Terms, contact us:
Email: legal@bluepeak-apps.com
Address: [INSERT ADDRESS]`
        }
      }
    }
  };

  const currentContent = content[language as keyof typeof content];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      {/* Header */}
      <div className="bg-white dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800">
        <div className="container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft className="w-4 h-4" />
                {currentContent.backToHome}
              </Button>
            </Link>
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-600" />
              <span className="text-sm text-slate-600 dark:text-slate-400">
                {currentContent.lastUpdated}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold font-space-grotesk text-slate-900 dark:text-white mb-4">
              {currentContent.title}
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto">
              {currentContent.intro}
            </p>
          </div>

          <div className="space-y-8">
            {Object.entries(currentContent.sections).map(([key, section]) => (
              <Card key={key} className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
                <CardContent className="p-8">
                  <h2 className="text-2xl font-semibold text-slate-900 dark:text-white mb-4">
                    {section.title}
                  </h2>
                  <div className="prose prose-slate dark:prose-invert max-w-none">
                    <div className="whitespace-pre-line text-slate-600 dark:text-slate-300">
                      {section.content}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Note about placeholder data */}
          <Card className="mt-12 bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800">
            <CardContent className="p-6 text-center">
              <div className="text-yellow-800 dark:text-yellow-200">
                <strong>
                  {language === 'de' ? 'Hinweis:' : 'Note:'} 
                </strong>
                {language === 'de' 
                  ? ' Diese AGB enthalten Platzhalter. Bitte ersetzen Sie alle [EINFÜGEN] Markierungen mit Ihren tatsächlichen Unternehmensinformationen.'
                  : ' These Terms contain placeholders. Please replace all [INSERT] markings with your actual company information.'
                }
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
