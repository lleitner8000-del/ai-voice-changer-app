
'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Brain, 
  Zap, 
  Shield, 
  Globe, 
  Cpu, 
  Sparkles,
  Bot,
  Mic,
  CloudLightning
} from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'Advanced Machine Learning',
    description: 'Cutting-edge ML algorithms that adapt and learn from your data to deliver unprecedented accuracy and insights.',
    color: 'text-blue-500'
  },
  {
    icon: Mic,
    title: 'AI Voice Processing',
    description: 'Real-time voice transformation and processing with studio-quality output for professional applications.',
    color: 'text-purple-500'
  },
  {
    icon: CloudLightning,
    title: 'Cloud-Native Architecture',
    description: 'Scalable, high-performance cloud infrastructure ensuring 99.9% uptime and global accessibility.',
    color: 'text-green-500'
  },
  {
    icon: Shield,
    title: 'Enterprise Security',
    description: 'Bank-grade security protocols with end-to-end encryption and compliance with industry standards.',
    color: 'text-red-500'
  },
  {
    icon: Bot,
    title: 'Intelligent Automation',
    description: 'Streamline workflows with AI-powered automation that understands context and adapts to changes.',
    color: 'text-orange-500'
  },
  {
    icon: Sparkles,
    title: 'Innovation Engine',
    description: 'Continuous innovation pipeline delivering new AI capabilities and features to stay ahead of the curve.',
    color: 'text-pink-500'
  }
];

export default function FeaturesSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section id="features" className="py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center space-y-4 mb-16"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-space-grotesk">
            Powerful AI <span className="text-primary">Features</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover the advanced capabilities that make BluePeak Apps the preferred choice for enterprise AI solutions.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-all duration-300 group cursor-pointer border-border/50 hover:border-primary/50">
                  <CardHeader className="space-y-4">
                    <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-muted group-hover:bg-primary/10 transition-colors duration-300">
                      <Icon className={`w-6 h-6 ${feature.color} group-hover:scale-110 transition-transform duration-300`} />
                    </div>
                    <CardTitle className="text-xl font-semibold font-space-grotesk group-hover:text-primary transition-colors duration-300">
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base leading-relaxed">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Additional Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-24 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8"
        >
          {[
            { label: 'API Calls/Month', value: '10M+', icon: Zap },
            { label: 'Data Processing', value: '5PB', icon: Cpu },
            { label: 'Global Reach', value: '50+', icon: Globe },
            { label: 'Uptime SLA', value: '99.9%', icon: Shield }
          ].map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={stat.label} className="text-center space-y-3 group">
                <div className="flex justify-center">
                  <Icon className="w-8 h-8 text-primary group-hover:scale-110 transition-transform duration-300" />
                </div>
                <div className="text-3xl sm:text-4xl font-bold text-primary font-space-grotesk">
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground font-medium">
                  {stat.label}
                </div>
              </div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
