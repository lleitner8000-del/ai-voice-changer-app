
'use client';

import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Mail, MessageCircle, Send, AlertCircle } from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '@/contexts/language-context';

export default function ContactSection() {
  const { language } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const content = {
    de: {
      title: "Kontakt",
      subtitle: "Haben Sie Fragen zu unseren Apps?",
      description: "Wir freuen uns auf Ihre Nachricht!",
      emailOnly: "Kontakt nur per E-Mail",
      name: "Name",
      email: "E-Mail",
      subject: "Betreff", 
      message: "Nachricht",
      send: "Nachricht senden",
      note: "Hinweis: Antworten erfolgen normalerweise innerhalb von 2-3 Werktagen.",
      placeholders: {
        name: "Ihr Name",
        email: "ihre.email@beispiel.de",
        subject: "Betreff Ihrer Anfrage",
        message: "Ihre Nachricht..."
      }
    },
    en: {
      title: "Contact",
      subtitle: "Questions about our apps?", 
      description: "We'd love to hear from you!",
      emailOnly: "Contact via email only",
      name: "Name",
      email: "Email",
      subject: "Subject",
      message: "Message", 
      send: "Send Message",
      note: "Note: Replies typically within 2-3 business days.",
      placeholders: {
        name: "Your name",
        email: "your.email@example.com", 
        subject: "Subject of your inquiry",
        message: "Your message..."
      }
    }
  };

  const currentContent = content[language as keyof typeof content];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const mailtoLink = `mailto:info@bluepeakapps.com?subject=${encodeURIComponent(formData.subject)}&body=${encodeURIComponent(
      `Name: ${formData.name}\nEmail: ${formData.email}\n\nMessage:\n${formData.message}`
    )}`;
    window.open(mailtoLink);
  };

  return (
    <section id="contact" className="py-20 bg-slate-50 dark:bg-slate-900">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk text-slate-900 dark:text-white mb-4">
            {currentContent.title}
          </h2>
          <p className="text-xl text-slate-600 dark:text-slate-300 mb-4">
            {currentContent.subtitle}
          </p>
          <p className="text-lg text-slate-500 dark:text-slate-400 max-w-2xl mx-auto">
            {currentContent.description}
          </p>
        </motion.div>

        <div className="max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Card className="bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 shadow-lg">
              <CardContent className="p-8">
                {/* Email-only Notice */}
                <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="flex items-center gap-2 text-blue-700 dark:text-blue-300 text-sm">
                    <Mail className="w-4 h-4" />
                    <span className="font-medium">{currentContent.emailOnly}</span>
                  </div>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                        {currentContent.name} *
                      </label>
                      <Input
                        required
                        placeholder={currentContent.placeholders.name}
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        className="bg-slate-50 dark:bg-slate-900 border-slate-300 dark:border-slate-600"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                        {currentContent.email} *
                      </label>
                      <Input
                        type="email"
                        required
                        placeholder={currentContent.placeholders.email}
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        className="bg-slate-50 dark:bg-slate-900 border-slate-300 dark:border-slate-600"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                      {currentContent.subject} *
                    </label>
                    <Input
                      required
                      placeholder={currentContent.placeholders.subject}
                      value={formData.subject}
                      onChange={(e) => setFormData({...formData, subject: e.target.value})}
                      className="bg-slate-50 dark:bg-slate-900 border-slate-300 dark:border-slate-600"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                      {currentContent.message} *
                    </label>
                    <Textarea
                      required
                      rows={6}
                      placeholder={currentContent.placeholders.message}
                      value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      className="bg-slate-50 dark:bg-slate-900 border-slate-300 dark:border-slate-600"
                    />
                  </div>

                  <div className="text-center">
                    <Button 
                      type="submit"
                      size="lg"
                      className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 font-semibold"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      {currentContent.send}
                    </Button>
                    
                    <div className="mt-4 p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-200 dark:border-amber-800">
                      <div className="flex items-center gap-2 text-amber-700 dark:text-amber-300 text-sm">
                        <AlertCircle className="w-4 h-4 flex-shrink-0" />
                        <span>{currentContent.note}</span>
                      </div>
                    </div>
                  </div>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
