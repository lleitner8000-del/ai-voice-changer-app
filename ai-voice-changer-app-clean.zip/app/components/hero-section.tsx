
'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Smartphone, Globe, ArrowRight, Languages } from 'lucide-react';
import { useLanguage } from '@/contexts/language-context';

export default function HeroSection() {
  const { language, setLanguage } = useLanguage();

  const content = {
    de: {
      badge: "Premium Mobile Apps",
      title: "Innovative Mobile",
      titleAccent: "KI Apps",
      description: "Entdecken Sie unsere hochwertigen KI-Apps für iOS und Android. Perfekt entwickelt für die bestmögliche mobile Erfahrung.",
      exploreApps: "Unsere Apps entdecken",
      tryDemo: "Demo ausprobieren"
    },
    en: {
      badge: "Premium Mobile Apps",
      title: "Innovative Mobile",
      titleAccent: "AI Apps",
      description: "Discover our high-quality AI apps for iOS and Android. Perfectly developed for the best mobile experience.",
      exploreApps: "Explore Our Apps",
      tryDemo: "Try Demo"
    }
  };

  const currentContent = content[language as keyof typeof content];

  const scrollToApps = () => {
    const element = document.getElementById('apps');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToDemo = () => {
    const element = document.getElementById('voice-changer-demo');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 dark:from-slate-900 dark:via-blue-950 dark:to-indigo-950">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-32 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-32 w-96 h-96 bg-indigo-400/20 rounded-full blur-3xl" />
      </div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center space-y-8 max-w-4xl mx-auto">
          {/* Language Switcher */}
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-end mb-4"
          >
            <div className="flex bg-white/90 dark:bg-slate-800/90 rounded-lg p-1 shadow-sm backdrop-blur-sm">
              <button 
                onClick={() => setLanguage('de')}
                className={`px-3 py-1 text-sm font-medium rounded-md transition-all ${
                  language === 'de' 
                    ? 'bg-blue-600 text-white shadow-sm' 
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                DE
              </button>
              <button 
                onClick={() => setLanguage('en')}
                className={`px-3 py-1 text-sm font-medium rounded-md transition-all ${
                  language === 'en' 
                    ? 'bg-blue-600 text-white shadow-sm' 
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                EN
              </button>
            </div>
          </motion.div>
          
          {/* Logo */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="flex justify-center mb-8"
          >
            <Image
              src="https://cdn.abacus.ai/images/527286a7-cbb7-44bc-9d3d-efb0b3fad431.png"
              alt="BluePeak Apps"
              width={400}
              height={120}
              className="h-20 w-auto md:h-24 lg:h-28 hover:scale-105 transition-transform duration-300"
              priority
            />
          </motion.div>
          
          {/* Main Headline */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-4"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 dark:bg-blue-900/30 rounded-full text-blue-700 dark:text-blue-300 text-sm font-medium">
              <Smartphone className="w-4 h-4" />
              {currentContent.badge}
            </div>
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold font-space-grotesk bg-gradient-to-r from-slate-900 via-blue-700 to-indigo-700 dark:from-white dark:via-blue-300 dark:to-indigo-300 bg-clip-text text-transparent leading-tight">
              {currentContent.title}
              <br />
              <span className="text-blue-600 dark:text-blue-400">{currentContent.titleAccent}</span>
            </h1>
            <p className="text-xl md:text-2xl text-slate-600 dark:text-slate-300 max-w-3xl mx-auto leading-relaxed">
              {currentContent.description}
            </p>
          </motion.div>
          
          {/* CTA Buttons */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4"
          >
            <Button 
              size="lg" 
              onClick={scrollToApps}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 group"
            >
              {currentContent.exploreApps}
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              onClick={scrollToDemo}
              className="px-8 py-6 text-lg font-semibold rounded-xl border-2 border-slate-200 dark:border-slate-700 hover:border-blue-300 dark:hover:border-blue-600 transition-all duration-300 group"
            >
              <Globe className="mr-2 w-5 h-5 group-hover:rotate-12 transition-transform" />
              {currentContent.tryDemo}
            </Button>
          </motion.div>
          
          {/* Store Badges */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="flex flex-col sm:flex-row gap-6 justify-center items-center pt-8"
          >
            <a 
              href="#apps" 
              onClick={(e) => { e.preventDefault(); scrollToApps(); }}
              className="hover:scale-105 transition-transform duration-300 opacity-90 hover:opacity-100"
            >
              <Image
                src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg"
                alt="Get it on Google Play"
                width={180}
                height={60}
                className="h-14 w-auto"
              />
            </a>
            <a 
              href="#apps"
              onClick={(e) => { e.preventDefault(); scrollToApps(); }}
              className="hover:scale-105 transition-transform duration-300 opacity-90 hover:opacity-100"
            >
              <Image
                src="https://upload.wikimedia.org/wikipedia/commons/3/3c/Download_on_the_App_Store_Badge.svg"
                alt="Download on the App Store"
                width={180}
                height={60}
                className="h-14 w-auto"
              />
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
