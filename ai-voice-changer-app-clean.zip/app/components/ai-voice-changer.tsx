
'use client';

import { motion } from 'framer-motion';
import { useState, useRef, useEffect } from 'react';
import { useLanguage } from '@/contexts/language-context';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Mic, Square, Play, Download, Upload, Volume2, Smartphone, ExternalLink, Clock } from 'lucide-react';

export default function AIVoiceChanger() {
  const { language } = useLanguage();
  const [isRecording, setIsRecording] = useState(false);
  const [audioFile, setAudioFile] = useState<File | null>(null);
  const [selectedVoice, setSelectedVoice] = useState('robot');
  const [demoTimeLeft, setDemoTimeLeft] = useState(30);
  const [showTimeLimit, setShowTimeLimit] = useState(false);
  const [hasRecording, setHasRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);

  const content = {
    de: {
      title: "KI Stimmenveränderer",
      subtitle: "Web-Demo • Kostenlos testen",
      description: "Verwandeln Sie Ihre Stimme in Echtzeit mit unserer fortschrittlichen KI-Technologie. Laden Sie Audio-Dateien hoch oder nehmen Sie direkt auf, wählen Sie einen von vielen kreativen Stimmeffekten und erleben Sie sofortige Transformation.",
      howItWorks: "So funktioniert es",
      step1: "Audio aufnehmen oder hochladen",
      step2: "Gewünschten Stimmeffekt auswählen", 
      step3: "KI verarbeitet in Sekundenschnelle",
      step4: "Transformierte Stimme anhören",
      limitation: "Demo-Beschränkung: 30 Sekunden Audio",
      uploadFile: "Audio hochladen",
      record: "Aufnehmen",
      stopRecording: "Stopp",
      selectVoice: "Stimme wählen",
      process: "Verarbeiten",
      downloadFull: "Vollversion herunterladen",
      mobileApps: "Mobile Apps für die beste Erfahrung",
      features: "Vollversion Features",
      demoInterface: "Demo Interface"
    },
    en: {
      title: "AI Voice Changer",
      subtitle: "Web Demo • Free Trial",
      description: "Transform your voice in real-time with our advanced AI technology. Upload audio files or record directly, choose from many creative voice effects and experience instant transformation.",
      howItWorks: "How it works",
      step1: "Record or upload audio",
      step2: "Select desired voice effect",
      step3: "AI processes in seconds", 
      step4: "Listen to transformed voice",
      limitation: "Demo Limitation: 30 seconds audio",
      uploadFile: "Upload Audio",
      record: "Record",
      stopRecording: "Stop",
      selectVoice: "Select Voice",
      process: "Process",
      downloadFull: "Download Full Version",
      mobileApps: "Mobile Apps for Best Experience",
      features: "Full Version Features",
      demoInterface: "Demo Interface"
    }
  };

  const currentContent = content[language as keyof typeof content];

  const voices = [
    { id: 'robot', name: 'Robot', icon: '🤖', description: { de: 'Roboter', en: 'Robot' } },
    { id: 'alien', name: 'Alien', icon: '👽', description: { de: 'Alien', en: 'Alien' } },
    { id: 'deep', name: 'Bass', icon: '🐻', description: { de: 'Bass', en: 'Bass' } },
    { id: 'echo', name: 'Echo', icon: '🏔️', description: { de: 'Echo', en: 'Echo' } }
  ];

  const fullVersionFeatures = {
    de: [
      "Unbegrenzte Aufnahmedauer",
      "15+ Premium-Stimmeffekte", 
      "Batch-Verarbeitung",
      "Hochqualitätiger Export",
      "Keine Wasserzeichen",
      "Offline-Modus"
    ],
    en: [
      "Unlimited recording duration",
      "15+ premium voice effects",
      "Batch processing", 
      "High-quality export",
      "No watermarks",
      "Offline mode"
    ]
  };

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isRecording && demoTimeLeft > 0) {
      timer = setInterval(() => {
        setDemoTimeLeft(prev => {
          if (prev <= 1) {
            setIsRecording(false);
            setShowTimeLimit(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isRecording, demoTimeLeft]);

  const handleRecord = async () => {
    if (demoTimeLeft <= 0) {
      setShowTimeLimit(true);
      return;
    }
    
    if (!isRecording) {
      try {
        // Echte Mikrofonaufnahme
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const recorder = new MediaRecorder(stream);
        const chunks: Blob[] = [];

        recorder.ondataavailable = (event) => {
          chunks.push(event.data);
        };

        recorder.onstop = () => {
          const audioBlob = new Blob(chunks, { type: 'audio/wav' });
          setAudioBlob(audioBlob);
          setHasRecording(true);
          const url = URL.createObjectURL(audioBlob);
          setAudioUrl(url);
          
          // Stoppe alle Tracks
          stream.getTracks().forEach(track => track.stop());
          
          alert(language === 'de' 
            ? '🎵 Aufnahme beendet! Audio bereit für Verarbeitung.' 
            : '🎵 Recording finished! Audio ready for processing.'
          );
        };

        recorder.start();
        setMediaRecorder(recorder);
        setIsRecording(true);
        setShowTimeLimit(false);

        alert(language === 'de' 
          ? '🎤 Aufnahme gestartet! Sprechen Sie jetzt...' 
          : '🎤 Recording started! Please speak now...'
        );

      } catch (error) {
        alert(language === 'de' 
          ? 'Mikrofonzugriff verweigert. Bitte erlauben Sie den Zugriff um die Demo zu testen!' 
          : 'Microphone access denied. Please allow access to test the demo!'
        );
      }
    } else {
      // Stoppe Aufnahme
      if (mediaRecorder && mediaRecorder.state === 'recording') {
        mediaRecorder.stop();
      }
      setIsRecording(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Demo limitation: simulate file upload
      setAudioFile(file);
      setHasRecording(true); // Auch bei Upload als Recording verfügbar markieren
      setTimeout(() => {
        alert(language === 'de' 
          ? '🎵 Audio-Datei erfolgreich hochgeladen! Bereit für Verarbeitung.' 
          : '🎵 Audio file uploaded successfully! Ready for processing.'
        );
      }, 1000);
    }
  };

  const generateDemoAudio = (voiceEffect: string) => {
    // Erstelle Demo-Audio mit Web Audio API
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const sampleRate = audioContext.sampleRate;
    const duration = 2; // 2 Sekunden
    const length = sampleRate * duration;
    const buffer = audioContext.createBuffer(1, length, sampleRate);
    const data = buffer.getChannelData(0);

    // Generiere Ton basierend auf Effekt
    for (let i = 0; i < length; i++) {
      let freq = 220; // A3 note
      if (voiceEffect === 'robot') freq = 150;
      if (voiceEffect === 'alien') freq = 350;
      if (voiceEffect === 'deep') freq = 110;
      if (voiceEffect === 'echo') freq = 220;

      data[i] = Math.sin(2 * Math.PI * freq * i / sampleRate) * 0.3;
      if (voiceEffect === 'echo' && i > sampleRate * 0.2) {
        data[i] += data[i - Math.floor(sampleRate * 0.2)] * 0.5;
      }
    }

    // Konvertiere zu WAV Blob
    const wavBuffer = audioBufferToWav(buffer);
    return new Blob([wavBuffer], { type: 'audio/wav' });
  };

  // Helper function für WAV conversion
  const audioBufferToWav = (buffer: AudioBuffer) => {
    const length = buffer.length;
    const arrayBuffer = new ArrayBuffer(44 + length * 2);
    const view = new DataView(arrayBuffer);
    const data = buffer.getChannelData(0);

    // WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    writeString(0, 'RIFF');
    view.setUint32(4, 36 + length * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, buffer.sampleRate, true);
    view.setUint32(28, buffer.sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length * 2, true);

    // Convert audio data
    let offset = 44;
    for (let i = 0; i < length; i++) {
      const sample = Math.max(-1, Math.min(1, data[i]));
      view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7FFF, true);
      offset += 2;
    }

    return arrayBuffer;
  };

  const handleProcess = () => {
    if (!audioFile && !hasRecording) {
      alert(language === 'de' 
        ? 'Bitte laden Sie zuerst eine Audio-Datei hoch oder nehmen Sie etwas auf!' 
        : 'Please upload an audio file or record something first!'
      );
      return;
    }
    
    setShowTimeLimit(true);
    
    // Simuliere Verarbeitung
    setTimeout(() => {
      const voiceName = voices.find(v => v.id === selectedVoice)?.description[language as keyof typeof voices[0]['description']] || selectedVoice;
      
      // Generiere Demo-Audio
      const demoAudio = generateDemoAudio(selectedVoice);
      const url = URL.createObjectURL(demoAudio);
      
      // Erstelle Download-Link
      const link = document.createElement('a');
      link.href = url;
      link.download = `demo_${selectedVoice}_effect.wav`;
      
      // Zeige Erfolgs-Dialog mit Download-Option
      const downloadNow = window.confirm(language === 'de' 
        ? `🎵 Demo-Audio mit ${voiceName}-Effekt wurde generiert!\n\n📥 Möchten Sie die Demo-Datei "demo_${selectedVoice}_effect.wav" herunterladen?\n\n✅ OK = Download\n❌ Abbrechen = Nur Meldung` 
        : `🎵 Demo audio with ${voiceName} effect generated!\n\n📥 Do you want to download "demo_${selectedVoice}_effect.wav"?\n\n✅ OK = Download\n❌ Cancel = Message only`
      );
      
      if (downloadNow) {
        link.click();
      }
      
      setShowTimeLimit(false);
      
      // Cleanup URL nach 5 Sekunden
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    }, 2000);
  };

  return (
    <section id="voice-changer-demo" className="py-20 bg-white dark:bg-slate-950">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300">
              {currentContent.subtitle}
            </Badge>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk text-slate-900 dark:text-white mb-4">
            {currentContent.title}
          </h2>
          <p className="text-xl text-slate-600 dark:text-slate-300 max-w-3xl mx-auto mb-8">
            {currentContent.description}
          </p>
          
          {/* How it works steps */}
          <div className="mb-8">
            <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-6">
              {currentContent.howItWorks}
            </h3>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {[
                { step: "1", text: currentContent.step1, icon: "📁" },
                { step: "2", text: currentContent.step2, icon: "🎭" },
                { step: "3", text: currentContent.step3, icon: "🤖" },
                { step: "4", text: currentContent.step4, icon: "🔊" }
              ].map((item, idx) => (
                <div key={idx} className="text-center">
                  <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-3 text-xl">
                    {item.icon}
                  </div>
                  <div className="text-xs font-semibold text-blue-600 dark:text-blue-400 mb-1">
                    {language === 'de' ? 'Schritt' : 'Step'} {item.step}
                  </div>
                  <div className="text-sm text-slate-600 dark:text-slate-300">
                    {item.text}
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-100 dark:bg-orange-900/30 rounded-lg text-orange-700 dark:text-orange-300 text-sm font-medium">
            <Clock className="w-4 h-4" />
            {currentContent.limitation}
          </div>
        </motion.div>

        {/* Connection banner */}
        <div className="mb-8">
          <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-blue-50 dark:from-blue-950/30 dark:via-indigo-950/30 dark:to-blue-950/30 rounded-2xl p-6 border border-blue-200 dark:border-blue-800">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                {language === 'de' 
                  ? 'Probieren Sie es aus – Erleben Sie die Vollversion'
                  : 'Try it out – Experience the full version'
                }
              </h3>
              <p className="text-slate-600 dark:text-slate-300 text-sm">
                {language === 'de' 
                  ? 'Links: Testen Sie unsere Web-Demo mit Grundfunktionen • Rechts: Entdecken Sie die unbegrenzten Möglichkeiten der mobilen Apps'
                  : 'Left: Test our web demo with basic features • Right: Discover unlimited possibilities of mobile apps'
                }
              </p>
            </div>
          </div>
        </div>

        {/* Anleitung direkt vor Demo */}
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-6 max-w-4xl mx-auto mb-8">
          <h3 className="text-lg font-semibold text-blue-900 dark:text-blue-300 mb-4 flex items-center gap-2">
            <span className="text-xl">🎯</span>
            {language === 'de' ? 'So funktioniert die Demo:' : 'How the demo works:'}
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
            <div className="flex items-start gap-3">
              <span className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">1</span>
              <p className="text-blue-800 dark:text-blue-200">
                {language === 'de' ? 'Audio hochladen oder aufnehmen' : 'Upload audio or record'}
              </p>
            </div>
            <div className="flex items-start gap-3">
              <span className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">2</span>
              <p className="text-blue-800 dark:text-blue-200">
                {language === 'de' ? 'Stimmeffekt wählen' : 'Choose voice effect'}
              </p>
            </div>
            <div className="flex items-start gap-3">
              <span className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">3</span>
              <p className="text-blue-800 dark:text-blue-200">
                {language === 'de' ? 'Auf "Verarbeiten" klicken' : 'Click "Process"'}
              </p>
            </div>
            <div className="flex items-start gap-3">
              <span className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0">4</span>
              <p className="text-blue-800 dark:text-blue-200">
                {language === 'de' ? '🎵 Ergebnis-Meldung erhalten' : '🎵 Get result message'}
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Demo Interface */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <Card className="bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-700">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-6">
                  {currentContent.demoInterface}
                </h3>

                {/* Audio Input */}
                <div className="space-y-4 mb-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                        {currentContent.uploadFile}
                      </label>
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={() => document.getElementById('file-upload')?.click()}
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Upload
                      </Button>
                      <input
                        id="file-upload"
                        type="file"
                        accept="audio/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                        {currentContent.record} ({demoTimeLeft}s)
                      </label>
                      <Button 
                        variant={isRecording ? "destructive" : "default"}
                        className="w-full"
                        onClick={handleRecord}
                      >
                        {isRecording ? (
                          <>
                            <Square className="w-4 h-4 mr-2 fill-current" />
                            {currentContent.stopRecording}
                          </>
                        ) : (
                          <>
                            <Mic className="w-4 h-4 mr-2" />
                            {currentContent.record}
                          </>
                        )}
                      </Button>
                    </div>
                  </div>

                  {showTimeLimit && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg border border-orange-200 dark:border-orange-800"
                    >
                      <div className="flex items-center gap-2 text-orange-700 dark:text-orange-300 text-sm">
                        <Clock className="w-4 h-4" />
                        <span className="font-medium">
                          {language === 'de' 
                            ? 'Demo-Limit erreicht! Für unbegrenzte Nutzung laden Sie die App herunter.'
                            : 'Demo limit reached! Download the app for unlimited usage.'
                          }
                        </span>
                      </div>
                    </motion.div>
                  )}

                  {/* Audio Player für Aufnahme */}
                  {audioUrl && (
                    <div className="mt-4">
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                        {language === 'de' ? 'Ihre Aufnahme anhören:' : 'Listen to your recording:'}
                      </label>
                      <audio controls className="w-full">
                        <source src={audioUrl} type="audio/wav" />
                      </audio>
                    </div>
                  )}

                  {/* Audio Player für hochgeladene Datei */}
                  {audioFile && (
                    <div className="mt-4">
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                        {language === 'de' ? 'Hochgeladene Datei anhören:' : 'Listen to uploaded file:'}
                      </label>
                      <audio controls className="w-full">
                        <source src={URL.createObjectURL(audioFile)} type={audioFile.type} />
                      </audio>
                    </div>
                  )}
                </div>

                {/* Voice Selection */}
                <div className="mb-6">
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-3">
                    {currentContent.selectVoice}
                  </label>
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    {voices.map((voice) => (
                      <button
                        key={voice.id}
                        onClick={() => setSelectedVoice(voice.id)}
                        className={`p-4 rounded-lg border transition-all text-center ${
                          selectedVoice === voice.id
                            ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300'
                            : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
                        }`}
                      >
                        <div className="text-2xl mb-2">{voice.icon}</div>
                        <div className="text-xs font-medium mb-1">{voice.name}</div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 break-words">
                          {voice.description[language as keyof typeof voice.description]}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Process Button */}
                <Button 
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={handleProcess}
                >
                  <Volume2 className="w-4 h-4 mr-2" />
                  {currentContent.process}
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          {/* Mobile App Promotion */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/50 dark:to-indigo-950/50 border-blue-200 dark:border-blue-800">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Smartphone className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-2">
                    {currentContent.mobileApps}
                  </h3>
                  <p className="text-slate-600 dark:text-slate-300 text-sm">
                    {language === 'de' 
                      ? 'Erleben Sie die volle Kraft unserer KI-Technologie in der mobilen App.'
                      : 'Experience the full power of our AI technology in the mobile app.'
                    }
                  </p>
                </div>

                <div className="space-y-4 mb-6">
                  <h4 className="font-semibold text-slate-900 dark:text-white text-sm">
                    {currentContent.features}:
                  </h4>
                  <div className="space-y-2">
                    {fullVersionFeatures[language as keyof typeof fullVersionFeatures].map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-3 text-sm text-slate-600 dark:text-slate-300">
                        <div className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0"></div>
                        {feature}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <Button 
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                    onClick={() => window.open('#', '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    {currentContent.downloadFull}
                  </Button>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => window.open('#', '_blank')}
                      className="text-xs"
                    >
                      <Smartphone className="w-3 h-3 mr-1" />
                      Google Play
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => window.open('#', '_blank')}
                      className="text-xs"
                    >
                      <Smartphone className="w-3 h-3 mr-1" />
                      App Store
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
