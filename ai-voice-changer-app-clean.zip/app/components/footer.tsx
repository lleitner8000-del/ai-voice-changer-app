
'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { useLanguage } from '@/contexts/language-context';
import { Badge } from '@/components/ui/badge';
import { Smartphone, Mail, MapPin, Phone } from 'lucide-react';

export default function Footer() {
  const { language } = useLanguage();

  const content = {
    de: {
      company: 'BluePeak Apps',
      tagline: 'Excellence in AI Innovation',
      description: 'Professionelle KI-Lösungen und Anwendungen für Unternehmen. Erleben Sie unseren innovativen KI Stimmenveränderer und weitere fortschrittliche Tools.',
      quickLinks: 'Schnellzugriff',
      legal: 'Rechtliches',
      contact: 'Kontakt',
      rights: 'Alle Rechte vorbehalten.',
      apps: 'Unsere Apps',
      demo: 'Demo testen',
      about: 'Über uns',
      privacy: 'Datenschutz',
      imprint: 'Impressum',
      terms: 'AGB',
      followUs: 'Folgen Sie uns'
    },
    en: {
      company: 'BluePeak Apps',
      tagline: 'Excellence in AI Innovation',
      description: 'Professional AI solutions and applications for enterprises. Experience our innovative AI Voice Changer and other advanced tools.',
      quickLinks: 'Quick Links',
      legal: 'Legal',
      contact: 'Contact',
      rights: 'All rights reserved.',
      apps: 'Our Apps',
      demo: 'Try Demo',
      about: 'About us',
      privacy: 'Privacy Policy',
      imprint: 'Imprint',
      terms: 'Terms',
      followUs: 'Follow us'
    }
  };

  const currentContent = content[language as keyof typeof content];

  return (
    <footer className="bg-slate-900 dark:bg-slate-950 text-white">
      <div className="container mx-auto px-6">
        {/* Main Footer Content */}
        <div className="py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="lg:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <img 
                  src="https://cdn.abacus.ai/images/5a5882bd-af96-4b3a-a11f-b50a9deadb59.png" 
                  alt="BluePeak Apps Logo"
                  className="w-10 h-10 rounded-lg"
                />
                <div>
                  <h3 className="text-xl font-bold font-space-grotesk">{currentContent.company}</h3>
                  <Badge variant="secondary" className="bg-blue-100 text-blue-700 text-xs">
                    {currentContent.tagline}
                  </Badge>
                </div>
              </div>
              <p className="text-slate-300 mb-6 max-w-md">
                {currentContent.description}
              </p>
              
              {/* Contact Info */}
              <div className="space-y-3 text-sm text-slate-400">
                <div className="flex items-center gap-3">
                  <Mail className="w-4 h-4" />
                  <span>bluepeakhelps@gmail.com</span>
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-lg font-semibold mb-4">{currentContent.quickLinks}</h4>
              <ul className="space-y-3 text-slate-300">
                <li>
                  <Link href="/#apps" className="hover:text-blue-400 transition-colors">
                    {currentContent.apps}
                  </Link>
                </li>
                <li>
                  <Link href="/#voice-changer-demo" className="hover:text-blue-400 transition-colors">
                    {currentContent.demo}
                  </Link>
                </li>
                <li>
                  <Link href="/#about" className="hover:text-blue-400 transition-colors">
                    {currentContent.about}
                  </Link>
                </li>
                <li>
                  <Link href="/#contact" className="hover:text-blue-400 transition-colors">
                    {currentContent.contact}
                  </Link>
                </li>
              </ul>
            </div>

            {/* Legal Links */}
            <div>
              <h4 className="text-lg font-semibold mb-4">{currentContent.legal}</h4>
              <ul className="space-y-3 text-slate-300">
                <li>
                  <Link href="/privacy" className="hover:text-blue-400 transition-colors">
                    {currentContent.privacy}
                  </Link>
                </li>
                <li>
                  <Link href="/imprint" className="hover:text-blue-400 transition-colors">
                    {currentContent.imprint}
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-blue-400 transition-colors">
                    {currentContent.terms}
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-slate-800 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-slate-400">
              © 2025 {currentContent.company}. {currentContent.rights}
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <Smartphone className="w-4 h-4" />
                <span>{language === 'de' ? 'Made in Switzerland' : 'Made in Switzerland'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
