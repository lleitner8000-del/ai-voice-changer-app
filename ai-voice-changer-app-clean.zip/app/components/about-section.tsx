
'use client';

import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import Image from 'next/image';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Target, 
  Eye, 
  Heart, 
  Lightbulb,
  Award,
  Rocket,
  Users
} from 'lucide-react';
import { useLanguage } from '@/contexts/language-context';

export default function AboutSection() {
  const { language } = useLanguage();
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const content = {
    de: {
      title: "Über BluePeak Apps",
      subtitle: "Wir helfen Menschen dabei, durch innovative KI-Apps mehr Erfolg zu erreichen und ihr volles Potenzial zu entfalten.",
      mission: {
        title: "Unsere Mission",
        text: "Menschen durch hochwertige KI-Apps zu mehr Erfolg zu verhelfen. Wir entwickeln intuitive, leistungsstarke mobile Anwendungen, die das Leben einfacher und produktiver machen. Jede App wird mit Leidenschaft und dem Ziel entwickelt, echten Mehrwert zu schaffen."
      },
      vision: {
        title: "Unsere Vision", 
        text: "Die führende Marke für Premium KI-Apps zu werden, die Menschen weltweit dabei unterstützen, ihre Ziele zu erreichen. Wir träumen von einer Welt, in der jeder Zugang zu den besten KI-Tools hat, um erfolgreicher und kreativer zu sein."
      },
      values: {
        title: "Unsere Werte",
        subtitle: "Die Prinzipien, die uns täglich leiten",
        items: [
          {
            title: "Qualität",
            description: "Wir entwickeln nur Apps, auf die wir stolz sind und die echten Nutzen bringen."
          },
          {
            title: "Einfachheit", 
            description: "Komplexe KI-Technologie, verpackt in einfach zu bedienende Apps."
          },
          {
            title: "Erfolg",
            description: "Der Erfolg unserer Nutzer ist unser größter Antrieb und Motivation."
          },
          {
            title: "Innovation",
            description: "Wir sind immer auf der Suche nach besseren Wegen, KI zu nutzen."
          }
        ]
      },
      commitment: {
        title: "Unser Versprechen",
        subtitle: "Wofür BluePeak Apps steht",
        items: [
          {
            icon: Heart,
            title: "Mit Leidenschaft entwickelt",
            description: "Jede App entsteht aus echter Begeisterung für Innovation"
          },
          {
            icon: Award,
            title: "Premium-Qualität", 
            description: "Höchste Standards bei Design und Funktionalität"
          },
          {
            icon: Rocket,
            title: "Zukunftsorientiert",
            description: "Wir denken voraus und entwickeln für morgen"
          },
          {
            icon: Users,
            title: "Nutzer im Mittelpunkt",
            description: "Ihre Bedürfnisse und Ihr Erfolg stehen an erster Stelle"
          }
        ]
      },
      closing: "Werden Sie Teil unserer Mission und entdecken Sie, wie unsere KI-Apps Ihnen zu mehr Erfolg verhelfen können."
    },
    en: {
      title: "About BluePeak Apps",
      subtitle: "We help people achieve greater success through innovative AI apps and unlock their full potential.",
      mission: {
        title: "Our Mission", 
        text: "To help people achieve greater success through high-quality AI apps. We develop intuitive, powerful mobile applications that make life simpler and more productive. Every app is created with passion and the goal of delivering real value."
      },
      vision: {
        title: "Our Vision",
        text: "To become the leading brand for premium AI apps that support people worldwide in achieving their goals. We dream of a world where everyone has access to the best AI tools to be more successful and creative."
      },
      values: {
        title: "Our Values",
        subtitle: "The principles that guide us daily",
        items: [
          {
            title: "Quality",
            description: "We only develop apps we're proud of that bring real benefits."
          },
          {
            title: "Simplicity",
            description: "Complex AI technology, packaged in easy-to-use apps."
          },
          {
            title: "Success", 
            description: "Our users' success is our greatest drive and motivation."
          },
          {
            title: "Innovation",
            description: "We're always looking for better ways to use AI."
          }
        ]
      },
      commitment: {
        title: "Our Promise",
        subtitle: "What BluePeak Apps stands for", 
        items: [
          {
            icon: Heart,
            title: "Built with passion",
            description: "Every app emerges from genuine enthusiasm for innovation"
          },
          {
            icon: Award,
            title: "Premium quality",
            description: "Highest standards in design and functionality"
          },
          {
            icon: Rocket,
            title: "Future-oriented",
            description: "We think ahead and develop for tomorrow"
          },
          {
            icon: Users,
            title: "Users first",
            description: "Your needs and success come first"
          }
        ]
      },
      closing: "Join our mission and discover how our AI apps can help you achieve greater success."
    }
  };

  const currentContent = content[language as keyof typeof content];

  return (
    <section id="about" className="py-20 bg-slate-50 dark:bg-slate-900">
      <div className="container mx-auto px-6">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center space-y-4 mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk text-slate-900 dark:text-white">
            {currentContent.title}
          </h2>
          <p className="text-xl text-slate-600 dark:text-slate-300 max-w-4xl mx-auto leading-relaxed">
            {currentContent.subtitle}
          </p>
        </motion.div>

        {/* Mission and Vision */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-20">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Card className="h-full bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
              <CardContent className="p-8 space-y-6">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-xl bg-blue-100 dark:bg-blue-900/30">
                    <Target className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h3 className="text-2xl font-bold font-space-grotesk text-slate-900 dark:text-white">
                    {currentContent.mission.title}
                  </h3>
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-lg">
                  {currentContent.mission.text}
                </p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <Card className="h-full bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
              <CardContent className="p-8 space-y-6">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-xl bg-blue-100 dark:bg-blue-900/30">
                    <Eye className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <h3 className="text-2xl font-bold font-space-grotesk text-slate-900 dark:text-white">
                    {currentContent.vision.title}
                  </h3>
                </div>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-lg">
                  {currentContent.vision.text}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Values Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mb-20"
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold font-space-grotesk text-slate-900 dark:text-white mb-4">
              {currentContent.values.title}
            </h3>
            <p className="text-slate-600 dark:text-slate-300">
              {currentContent.values.subtitle}
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {currentContent.values.items.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: 0.8 + index * 0.1 }}
                className="text-center space-y-4 group"
              >
                <div className="flex justify-center">
                  <div className="p-4 rounded-xl bg-blue-100 dark:bg-blue-900/30 group-hover:bg-blue-200 dark:group-hover:bg-blue-900/50 transition-colors duration-300">
                    <Lightbulb className="w-8 h-8 text-blue-600 dark:text-blue-400 group-hover:scale-110 transition-transform duration-300" />
                  </div>
                </div>
                <h4 className="text-xl font-semibold font-space-grotesk text-slate-900 dark:text-white">
                  {value.title}
                </h4>
                <p className="text-sm text-slate-600 dark:text-slate-300">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <Separator className="my-16 bg-slate-200 dark:bg-slate-700" />

        {/* Commitment */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1.0 }}
          className="mb-16"
        >
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold font-space-grotesk text-slate-900 dark:text-white mb-4">
              {currentContent.commitment.title}
            </h3>
            <p className="text-slate-600 dark:text-slate-300">
              {currentContent.commitment.subtitle}
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {currentContent.commitment.items.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={inView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ duration: 0.5, delay: 1.2 + index * 0.1 }}
                  className="text-center space-y-4 group"
                >
                  <div className="flex justify-center">
                    <div className="p-4 rounded-xl bg-green-100 dark:bg-green-900/30 group-hover:bg-green-200 dark:group-hover:bg-green-900/50 transition-colors duration-300">
                      <Icon className="w-8 h-8 text-green-600 dark:text-green-400 group-hover:scale-110 transition-transform duration-300" />
                    </div>
                  </div>
                  <h4 className="text-lg font-semibold text-slate-900 dark:text-white">
                    {item.title}
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-300">
                    {item.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Company Logo */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1.4 }}
          className="text-center"
        >
          <div className="flex justify-center mb-6">
            <div className="relative">
              <Image
                src="https://cdn.abacus.ai/images/527286a7-cbb7-44bc-9d3d-efb0b3fad431.png"
                alt="BluePeak Apps"
                width={300}
                height={80}
                className="object-contain opacity-80 hover:opacity-100 transition-opacity duration-300"
              />
            </div>
          </div>
          <p className="text-lg text-slate-600 dark:text-slate-300 max-w-3xl mx-auto leading-relaxed">
            {currentContent.closing}
          </p>
        </motion.div>
      </div>
    </section>
  );
}
