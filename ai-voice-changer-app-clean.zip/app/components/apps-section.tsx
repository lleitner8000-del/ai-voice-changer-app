
'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Mic, Star, Download, ExternalLink, Smartphone } from 'lucide-react';
import { useLanguage } from '@/contexts/language-context';

export default function AppsSection() {
  const { language } = useLanguage();

  const content = {
    de: {
      title: "Unsere Apps",
      subtitle: "Premium KI-Apps für iOS & Android",
      description: "Jede App wurde mit Liebe zum Detail entwickelt und bietet höchste Qualität für mobile Benutzer.",
      comingSoon: "Weitere Apps folgen bald...",
      features: "Features",
      download: "Jetzt herunterladen",
      tryDemo: "Web-Demo testen",
      rating: "Bewertung"
    },
    en: {
      title: "Our Apps",
      subtitle: "Premium AI Apps for iOS & Android",
      description: "Each app is crafted with attention to detail, offering the highest quality for mobile users.",
      comingSoon: "More apps coming soon...",
      features: "Features",
      download: "Download Now",
      tryDemo: "Try Web Demo",
      rating: "Rating"
    }
  };

  const currentContent = content[language as keyof typeof content];

  const apps = [
    {
      id: 'voice-changer',
      name: 'AI Voice Changer',
      nameDE: 'KI Stimmenveränderer',
      icon: <Mic className="w-8 h-8" />,
      description: {
        de: "Verwandeln Sie Ihre Stimme in Echtzeit mit fortschrittlicher KI-Technologie. Perfekt für Content-Creator, Gamer, Podcaster und alle, die kreative Stimmeffekte benötigen. Auch ideal für Privatsphäre-Schutz bei Online-Calls.",
        en: "Transform your voice in real-time with advanced AI technology. Perfect for content creators, gamers, podcasters, and anyone needing creative voice effects. Also ideal for privacy protection in online calls."
      },
      features: {
        de: ["Echtzeit-Verarbeitung", "15+ Stimmeffekte", "Roboter, Alien, Echo", "Tiefe & hohe Stimmen", "Batch-Verarbeitung", "Offline verfügbar"],
        en: ["Real-time processing", "15+ voice effects", "Robot, Alien, Echo", "Deep & high voices", "Batch processing", "Offline available"]
      },
      rating: 4.8,
      price: "€2.99",
      playStoreUrl: "#",
      appStoreUrl: "#",
      demoAvailable: true,
      image: "https://cdn.abacus.ai/images/5a5882bd-af96-4b3a-a11f-b50a9deadb59.png"
    }
  ];

  const scrollToDemo = () => {
    const element = document.getElementById('voice-changer-demo');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="apps" className="py-20 bg-slate-50 dark:bg-slate-900">
      <div className="container mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold font-space-grotesk text-slate-900 dark:text-white mb-4">
            {currentContent.title}
          </h2>
          <p className="text-xl text-slate-600 dark:text-slate-300 mb-2">
            {currentContent.subtitle}
          </p>
          <p className="text-lg text-slate-500 dark:text-slate-400 max-w-2xl mx-auto">
            {currentContent.description}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
          {apps.map((app, index) => (
            <motion.div
              key={app.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="app-card"
            >
              <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 group bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
                <CardContent className="p-6">
                  {/* App Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-xl flex items-center justify-center text-blue-600 dark:text-blue-400">
                        {app.icon}
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                          {language === 'de' ? app.nameDE : app.name}
                        </h3>
                        <div className="flex items-center gap-2 mt-1">
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 text-yellow-500 fill-current" />
                            <span className="text-sm font-medium text-slate-600 dark:text-slate-300">
                              {app.rating}
                            </span>
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            {app.price}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* App Description */}
                  <p className="text-slate-600 dark:text-slate-300 mb-4">
                    {app.description[language as keyof typeof app.description]}
                  </p>

                  {/* Features */}
                  <div className="mb-6 features-list" id="features-section">
                    <h4 className="text-sm font-semibold text-slate-900 dark:text-white mb-2">
                      {currentContent.features}:
                    </h4>
                    <div className="grid grid-cols-2 gap-2">
                      {app.features[language as keyof typeof app.features].map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300">
                          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                          {feature}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Download Buttons */}
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <Button 
                        size="sm" 
                        className="bg-blue-600 hover:bg-blue-700 text-white group-hover:scale-105 transition-all duration-300"
                        onClick={() => window.open(app.playStoreUrl, '_blank')}
                      >
                        <Smartphone className="w-4 h-4 mr-2" />
                        Android
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        className="border-slate-300 dark:border-slate-600 group-hover:scale-105 transition-all duration-300"
                        onClick={() => window.open(app.appStoreUrl, '_blank')}
                      >
                        <Smartphone className="w-4 h-4 mr-2" />
                        iOS
                      </Button>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={(e) => {
                          // Scrolle zur Features-Liste in derselben App-Karte
                          const button = e.target as HTMLElement;
                          const appCard = button.closest('.app-card');
                          const featuresSection = appCard?.querySelector('.features-list');
                          if (featuresSection) {
                            featuresSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
                            featuresSection.classList.add('highlight-features');
                            setTimeout(() => featuresSection.classList.remove('highlight-features'), 2000);
                          }
                        }}
                        className="text-slate-600 dark:text-slate-300 border-slate-300 dark:border-slate-600"
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        {currentContent.features}
                      </Button>
                      {app.demoAvailable && (
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={scrollToDemo}
                          className="text-blue-600 hover:text-blue-700 hover:bg-blue-50 dark:text-blue-400 dark:hover:bg-blue-900/20"
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Demo
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}

          {/* Coming Soon Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <Card className="overflow-hidden bg-gradient-to-br from-slate-100 to-slate-200 dark:from-slate-800 dark:to-slate-700 border-dashed border-2 border-slate-300 dark:border-slate-600">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-slate-300 dark:bg-slate-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Smartphone className="w-8 h-8 text-slate-500 dark:text-slate-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-600 dark:text-slate-300 mb-2">
                  {currentContent.comingSoon}
                </h3>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  {language === 'de' 
                    ? 'Bleiben Sie dran für weitere innovative KI-Apps!'
                    : 'Stay tuned for more innovative AI apps!'
                  }
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
