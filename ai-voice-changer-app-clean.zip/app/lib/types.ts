
export interface ContactFormData {
  id: string;
  name: string;
  email: string;
  company: string;
  message: string;
  phone?: string;
  timestamp: Date;
  status: 'new' | 'contacted' | 'closed';
  form_type: 'contact' | 'demo_request';
}

export interface AudioSettings {
  pitch: number;
  reverb: number;
  distortion: number;
  robotize: boolean;
  deepVoice: boolean;
  highPitch: boolean;
  alien: boolean;
  echo: number;
}

export interface VoiceCharacter {
  id: string;
  name: string;
  description: string;
  settings: AudioSettings;
  icon: string;
}

export const DEFAULT_VOICE_CHARACTERS: VoiceCharacter[] = [
  {
    id: 'robot',
    name: 'Robot',
    description: 'Futuristic robotic voice',
    settings: { pitch: 0.8, reverb: 0.3, distortion: 0.4, robotize: true, deepVoice: false, highPitch: false, alien: false, echo: 0.2 },
    icon: 'Bot'
  },
  {
    id: 'alien',
    name: 'Alien',
    description: 'Otherworldly alien voice',
    settings: { pitch: 1.3, reverb: 0.5, distortion: 0.3, robotize: false, deepVoice: false, highPitch: false, alien: true, echo: 0.4 },
    icon: 'Zap'
  },
  {
    id: 'deep',
    name: 'Deep Voice',
    description: 'Deep, authoritative voice',
    settings: { pitch: 0.6, reverb: 0.2, distortion: 0.1, robotize: false, deepVoice: true, highPitch: false, alien: false, echo: 0.1 },
    icon: 'Volume2'
  },
  {
    id: 'chipmunk',
    name: 'Chipmunk',
    description: 'High-pitched, fast voice',
    settings: { pitch: 1.8, reverb: 0.1, distortion: 0.0, robotize: false, deepVoice: false, highPitch: true, alien: false, echo: 0.05 },
    icon: 'Volume'
  }
];
